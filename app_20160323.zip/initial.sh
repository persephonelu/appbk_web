#!/bin/sh
#########################################################################
# Author: billczhang
# Created Time: Wed 01 Jul 2015 02:40:58 PM CST
# File Name: initial.sh
# Description: initial git
#########################################################################
git init
