/**
 * @ngdoc function
 * @name appbkApp.controller:RankCtrl
 * @description
 * # RankCtrl
 * Controller of the appbkApp
 */
angular.module('rank')

  //主控制器
    .controller('rank_controller', function($scope,$localStorage,app, $location,user_app , user, auth)
    {
      document.title = "APP运营助手_ASO_App Store应用市场优化";


      if(typeof($localStorage.email) == "undefined") //如果没有登录
      {
        $scope.user_login_show = false;
        $scope.user_not_login_show = true;
        $scope.register_or_login = "现在注册";
        $scope.register_or_login_url = "register.html";
      }
      else//如果已经登录，获得登录信息
      {
        $scope.user_login_show = true;
        $scope.user_not_login_show = false;
        $scope.user_info = user.get_user_info().get({"email":$localStorage.email,"token":$localStorage.token});
        $scope.register_or_login = "现在使用";
        $scope.register_or_login_url = "user_main.html";


        user_app.get_user_apps().query({"email":$localStorage.email,"token":$localStorage.token}, function(data)
        {
          //如果尚未添加app
          if (data.length==0) {
            $scope.message = "尚未添加app，请点击右上角'app管理'，添加app";
            return;
          }
          $scope.app = {}; //选择的app
          $scope.apps = data; //app列表
          $scope.app.selected = data[0]; //显示的选项

          //首次进入页面，如果没有，选择一个app_id
          if (typeof($localStorage.app_id) == "undefined") //如果没有设置过
          {
            $localStorage.app_id = $scope.apps[0].app_id;
            $localStorage.$save();
          }
        });
      }

      //退出
      $scope.logout = function()
      {
        auth.logout();
      }

      //app search 搜索
      $scope.app_search = function()
      {
        var name = $scope.n;
        $location.path("app_search/" + name);
      }



      //选择一个app
      $scope.select_app = function(app_id)
      {
        console.log("rank_controller select_app" + app_id);
        //获得app基本信息
        //$localStorage.app_id = app_id;
        //$localStorage.$save();
        app.get_app_info().get({"app_id":app_id}, function(data)
        {
          $scope.app_info = data;
          window.location = 'user_main.html#/app_content/' + app_id;
        });
        app.get_app_info().get({"app_id":$localStorage.app_id}, function(data)
        {

          console.log("index_main_controller.get_app_info");
          $scope.app_info = data;
          //根据上次访问的页面，跳转到不同页面
          if (typeof($localStorage.visit_url) == "undefined") //如果没有设置过,跳转到信息页
          {
            window.location = 'user_main.html#/app_content/' + app_id;
          }
          else
          {
            window.location = 'user_main.html#/'+ $localStorage.visit_url;
          }
        });
      }



    })


    .controller('user_app_manage_controller', function($scope,$localStorage,$location,$anchorScroll, user_app, app) {

      //tab菜单管理
      $scope.old_app_tab = true;
      $scope.new_app_tab = false;

      //获得用户app列表
      get_user_apps();

      //删除用户app
      $scope.del_user_app = function(app_id)
      {
        //真实删除数据
        user_app.del_user_app().get({"email":$localStorage.email,"token":$localStorage.token,"app_id":app_id},function(data)
        {
          //刷新页面
          get_user_apps();

          //go to app_info,刷新页面，不能$locaiton.href
          window.location = 'user_main.html';
        });
      }

      //点击一个app，进入信息页面
      $scope.go_app_info = function(app)
      {
        //定位到顶部
        $location.hash('top');
        $anchorScroll();

        //写cookie
        $localStorage.app_id = app.app_id;
        $localStorage.$save();

        //右上角选择
        $scope.app.selected = app; //显示的选项

        //go to app_info,刷新页面，不能$locaiton.href
        window.location = 'user_main.html#/';
        location = 'user_main.html#/app_content/' + app.app_id;
      }

      //搜索app
      $scope.search_app = function()
      {
        query = $scope.query;
        //获得搜索结果数据
        app.get_app_search_results().get({"email":$localStorage.email,"token":$localStorage.token,"n":query},function(data)
        {
          $scope.app_search_results = data.results;
          if ( data.results.length == 0 ) //如果没有搜索结果
          {
            $scope.message = "没有相关结果,可尝试直接搜索你的app id";
          }
        });
        $scope.api_search_show = true;
      }


      $scope.get_api_app_search_results = function()
      {
        name = $scope.query;
        $scope.app_search_results = {};
        $scope.api_search_wait = true;
        app.get_api_app_search_results().get({"n":name}, function(data)
        {
          $scope.app_search_results = data.results;
          if ( data.results.length == 0 ) //如果没有搜索结果
          {
            $scope.message = "没有相关结果";
          }
          $scope.api_search_show = false;
          $scope.api_search_wait = false;
        });
      }

      //根据app_id添加app
      $scope.add_user_app = function(app_id)
      {
        //真实后台添加数据
        user_app.add_user_app().get({"email":$localStorage.email,"token":$localStorage.token,"app_id":app_id},function(data)
        {
          //刷新页面
          get_user_apps();
          //go to app_info,刷新页面，不能$locaiton.href
          window.location = 'user_main.html';

        });
      }

      //tab点击
      //已提交app市场的tab
      $scope.old_app_tab_click = function()
      {
        $scope.old_app_tab = true;
        $scope.new_app_tab = false;
      }

      //未提交app市场的tab
      $scope.new_app_tab_click = function()
      {
        $scope.old_app_tab = false;
        $scope.new_app_tab = true;
        //加载app类别代码
        $scope.categories  = app.get_categories().query();

      }

      //添加未提交到市场上的app
      $scope.add_new_app = function ()
      {
        name = $scope.new_app_name;
        description = $scope.new_app_description;
        category = $scope.new_app_category;
        icon = "http://appbk.oss-cn-hangzhou.aliyuncs.com/images/57.png";

        //真实后台添加数据
        user_app.add_user_new_app().get({"email":$localStorage.email,"token":$localStorage.token,"n":name,"d":description,"c":category},function(data)
        {
          //刷新页面
          get_user_apps();
          //go to app_info,刷新页面，不能$locaiton.href
          window.location = 'user_main.html';
        });
      }

      //获得app列表,刷新页面
      function get_user_apps()
      {
        //console.log("get_user_apps");
        $scope.user_app_show_wait = true;
        user_app.get_user_apps().query({"email":$localStorage.email,"token":$localStorage.token},function(data)
        {
          $scope.apps = data;
          $scope.user_app_show_wait = false;
          $localStorage.app_id = data[0].app_id;
          $localStorage.$save();
        });
      }
    })

  //index main控制器
    .controller('index_main_controller', function($scope,$http, $location,app)
    {
      //app search 搜索
      $scope.app_search = function()
      {
        var name = $scope.name;
        $location.path("app_search/" + name);
      }

      ////选择一个app
      //$scope.select_app = function(app_id)
      //{
      //  console.log("select_app" + app_id);
      //  //获得app基本信息
      //  $localStorage.app_id = app_id;
      //  $localStorage.$save();
      //
      //  app.get_app_info().get({"app_id":$localStorage.app_id}, function(data)
      //  {
      //    console.log("index_main_controller.get_app_info");
      //    $scope.app_info = data;
      //    //根据上次访问的页面，跳转到不同页面
      //    if (typeof($localStorage.visit_url) == "undefined") //如果没有设置过,跳转到信息页
      //    {
      //      window.location = 'user_main.html#/user_app_info';
      //    }
      //    else
      //    {
      //      window.location = 'user_main.html#/'+ $localStorage.visit_url;
      //    }
      //  });
      //}


    })

  //用户登录控制器
    .controller("index_login_controller", function($scope , $localStorage,$location, user)
    {
      //登录
      $scope.login = function()
      {
        console.log("login method");
        email = $scope.email;
        password = $scope.password;

        user.check_user_login_input().get({"email":email,"password":password}, function(data)
        {
          console.log("check_user_login_input method");
          if (data.status>=0) //如果正确
          {
            console.log("check_user_login_input method 如果正确");

            //删除原有cookie
            if (typeof($localStorage.app_id)!="undefined")
            {
              delete  $localStorage.app_id;
            }
            //保持cookie
            $localStorage.token = data.token;
            $localStorage.email = email;
            $localStorage.expire = data.expire; //本地存储过期时间，过期后必须重新登录
            $localStorage.$save();

            //window.history.back();
            //window.location.reload();
            window.location = 'index.html'; //revise by maris
          }
          else
          {
            console.log("check_user_login_input method data.message");

            //展示错误页面,密码错误，或者服务到期等。
            $scope.message = data.message;
          }
        });
      }
    })

//用户注册控制器
    .controller('index_register_controller',function($scope, $localStorage,user)
    {
      $scope.register_user = function()
      {
        email = $scope.email;
        password = $scope.password;
        password_check = $scope.password_check;
        //判断两个输入是否一致
        if ( password != password_check)
        {
          $scope.message = "两次输入的密码不一致，请检查后重新输入";
          return -1;
        }
        else
        {
          $scope.message = "";
        }

        //从服务器端获取注册信息是否正确的信息
        user.check_user_register_input().get({"email":email,"password":password}, function(data)
        {
          if (data.status>=0) //如果正确
          {
            $scope.message = "";
            //注册
            user.reg_user().get({"email":email,"password":password}, function(data)
            {
              //删除原有cookie
              if (typeof($localStorage.app_id)!="undefined")
              {
                delete  $localStorage.app_id;
              }

              //保持cookie
              $localStorage.token = data.token;
              $localStorage.email = email;
              $localStorage.$save();
              //跳转到用户app页面
              window.location = 'user_main.html';
              //setTimeout("window.location = 'user_main.html'",1000);//延时1秒,否则写localstorate有问题
            });
          }
          else
          {
            //展示错误页面
            $scope.message = data.message;
          }
        });
      }
    })

//tag_rank的控制器
    .controller('tag_rank_controller', function($scope, app, app_weibo)
    {
      document.title = "用户标签排行榜_AppBK.com";
      //获得一级类别信息
      $scope.categories = app.get_categories().query();

      //获得游戏二级类别信息
      $scope.game_categories = app.get_game_categories().query();

      //只要30个，不翻页,预先选择一个类别
      $scope.category_selected = "天气";
      get_tag_rank($scope.category_selected);

      //点击时，获得某个类别下的app排行
      $scope.get_category_tag_rank = function(category)
      {
        get_tag_rank(category);
      }

      function get_tag_rank(category)
      {
        $scope.category_selected = category;
        $scope.tag_rank = {};//先清空数据
        $scope.loading_show = true;
        app_weibo.get_tag_rank().query({"c":category},function(data)
        {
          $scope.tag_rank = data;
          $scope.loading_show = false;
        });
      }
    })

//word_rank的控制器
    .controller('word_rank_controller', function($scope, $location, word, app)
    {
      document.title = "关键词排行榜_AppBK.com"
      //bootstrap tips
      $("[data-toggle='popover']").popover({trigger:'click| hover',placement:'top',html:true});

      var limit = 30; //每页的记录个数
      //获得一级类别信息
      $scope.categories = app.get_categories().query();

      //获得游戏二级类别信息
      $scope.game_categories = app.get_game_categories().query();

      //只要30个，不翻页
      $scope.category_selected = "总榜";
      get_word_rank($scope.category_selected,1);

      //点击下拉菜单时，获得某个类别下的app关键词榜单
      $scope.get_category_word_rank = function(category)
      {
        get_word_rank(category,1);
      }

      //关键词表格
      //使用ui gird
      //表格基础配置
      $scope.word_grid = {
        enableRowSelection: true,
        enableSelectAll: false,
        selectionRowHeaderWidth: 100,
        rowHeight: 35,
        enableRowHeaderSelection: true,
        showGridFooter:false,
        enableGridMenu: true,//menu
        exporterOlderExcelCompatibility: true,
        exporterCsvFilename: 'appbk.csv',
      };

      var columm_config =  [
        {field: 'num', displayName: '序号',type:'number',width:'7%', cellTemplate: '<div class="ui-grid-cell-contents table-middle-style">{{grid.renderContainers.body.visibleRowCache.indexOf(row)+1}}</div>'},
        {field: 'word', displayName: '搜索词',type:'string',width:'15%',cellTemplate:"<div class='ui-grid-cell-contents'><a target='_blank' href='#/app_search/{{MODEL_COL_FIELD}}' title='{{MODEL_COL_FIELD}}'>{{MODEL_COL_FIELD|limitTo:8}}</a></div>"},
        {field: 'rank', displayName: '搜索热度', type:'number', width:'15%',headerTooltip: "搜索热度：主要反映用户每天搜索该词的频率", cellTemplate:"<div class='ui-grid-cell-contents'><h5><progressbar class='progress-striped table_middle' type='warning'  max='10000' value='MODEL_COL_FIELD'>{{MODEL_COL_FIELD}}</progressbar></h5></div>"},
        {field: 'num', displayName: "搜索结果数",width:'13%', type:'number',cellTemplate: '<div class="ui-grid-cell-contents">{{MODEL_COL_FIELD}}</div>'},
        {field: 'name', displayName: "第1名APP", type:'string', width:'50%',enableSorting: false,cellTemplate:"<div class='ui-grid-cell-contents'><a target='_blank' href='user_main.html#/app_content/{{row.entity.app_id}}' title='{{MODEL_COL_FIELD}}'><span class='c2'>{{MODEL_COL_FIELD}}</span></a></div>"},
      ];
      $scope.word_grid.columnDefs = columm_config;

      //加载更多数据
      $scope.load_more = function(current_page)
      {
        category = $scope.category_selected;
        $scope.current_page = current_page + 1;
        get_word_rank(category,current_page+1);
        if ($scope.current_page >= $scope.max_page_num)
        {
          $scope.turn_page = false;
        }
        else
        {
          $scope.turn_page = true;
        }
      }


      //选择一个类别，获得热门关键词
      function get_word_rank(category,page)
      {
        $scope.category_selected = category;
        var start = limit * (page - 1);
        $scope.start = start;
        $scope.loading_show = true;

        word.get_word_rank().get({"c": category, "start": start, "limit": limit}, function (data)  {


          if (start == 0) { //如果是首次调用
            $scope.word_grid.data = [] ;//清空数据
            //翻页构造
            $scope.total_items = data.num; //总数据数
            $scope.items_per_page = limit; //每页的记录数
            $scope.start = 0;//html的记录index显示
            $scope.current_page = 1;//设置当前页
            $scope.max_page_num = parseInt(data.num/limit) + 1;
            if ($scope.max_page_num >1)
            {
              $scope.turn_page = true;
            }
            else
            {
              $scope.turn_page = false;
            }
          }

          //插入新数据
          for (var i=0;i<data.results.length;i++) {
            $scope.word_grid.data.push(data.results[i]);
          }

          $scope.loading_show = false;

        });
      }

      //word search 搜索
      $scope.word_search = function()
      {
        name = $scope.name;
        $location.path("word_search/" + name);
      }
    })


  //word_rank的控制器
    .controller('word_rank_inter_controller', function($scope, $location, word, app)
    {
        document.title = "关键词排行榜_AppBK.com"
      //bootstrap tips
      $("[data-toggle='popover']").popover({trigger:'click| hover',placement:'top',html:true});

      var limit = 30; //每页的记录个数
      //获得一级类别信息
      $scope.categories = app.get_categories().query();

      //获得游戏二级类别信息
      $scope.game_categories = app.get_game_categories().query();

      $scope.countrys = ["泰国"];
      //只要30个，不翻页
      $scope.category_selected = "天气";
      $scope.country_selected = $scope.countrys[0];

      get_word_rank($scope.category_selected,$scope.country_selected,1);

      //点击下拉菜单时，获得某个类别下的app关键词榜单
      $scope.get_category_word_rank = function(category)
      {
        get_word_rank(category,$scope.country_selected,1);
      }

      $scope.select_country = function(country)
      {
        console.log("select_country"+country);
        get_word_rank($scope.category_selected,country,1);

      }



      //关键词表格
      //使用ui gird
      //表格基础配置
      $scope.word_grid = {
        enableRowSelection: true,
        enableSelectAll: false,
        selectionRowHeaderWidth: 100,
        rowHeight: 35,
        enableRowHeaderSelection: true,
        showGridFooter:false,
        enableGridMenu: true,//menu
        exporterOlderExcelCompatibility: true,
        exporterCsvFilename: 'appbk.csv',
      };

      var columm_config =  [
        {field: 'num', displayName: '序号',type:'number',width:80, cellTemplate: '<div class="ui-grid-cell-contents">{{grid.renderContainers.body.visibleRowCache.indexOf(row)+1}}</div>'},
        {field: 'word', displayName: '搜索词',type:'string',width:150,cellTemplate:"<span  class='table_middle'><a target='_blank' href='#/app_search/{{MODEL_COL_FIELD}}' title='{{MODEL_COL_FIELD}}'>{{MODEL_COL_FIELD|limitTo:8}}</a></span>"},
        {field: 'rank', displayName: '搜索热度', type:'number', width:150,headerTooltip: "搜索热度：主要反映用户每天搜索该词的频率", cellTemplate:"<h5><progressbar class='progress-striped table_middle' type='warning'  max='10000' value='MODEL_COL_FIELD'>{{MODEL_COL_FIELD}}</progressbar></h5>"},
        {field: 'num', displayName: "搜索结果数",width:130, type:'number'},
        {field: 'name', displayName: "第1名APP", type:'string', width:200,enableSorting: false,cellTemplate:"<a target='_blank' href='index.html#/app_content/{{row.entity.app_id}}' title='{{MODEL_COL_FIELD}}'>{{MODEL_COL_FIELD|limitTo:10}}</a>"},
      ];
      $scope.word_grid.columnDefs = columm_config;

      //加载更多数据
      $scope.load_more = function(current_page)
      {
        category = $scope.category_selected;
        $scope.current_page = current_page + 1;
        get_word_rank(category, $scope.country_selected,current_page+1);
        if ($scope.current_page >= $scope.max_page_num)
        {
          $scope.turn_page = false;
        }
        else
        {
          $scope.turn_page = true;
        }
      }


      //选择一个类别，获得热门关键词
      function get_word_rank(category,country,page)
      {
        console.log("get_word_rank:" + category + country + "_"+page);
        $scope.category_selected = category;
        $scope.country_selected = country;

        var start = limit * (page - 1);
        $scope.start = start;

        word.get_word_rank_inter().get({"c": category, "start": start, "limit": limit}, function (data)  {


          if (start == 0) { //如果是首次调用
            $scope.word_grid.data = [] ;//清空数据
            //翻页构造
            $scope.total_items = data.num; //总数据数
            $scope.items_per_page = limit; //每页的记录数
            $scope.start = 0;//html的记录index显示
            $scope.current_page = 1;//设置当前页
            $scope.max_page_num = parseInt(data.num/limit) + 1;
            if ($scope.max_page_num >1)
            {
              $scope.turn_page = true;
            }
            else
            {
              $scope.turn_page = false;
            }
          }

          //插入新数据
          for (var i=0;i<data.results.length;i++) {
            $scope.word_grid.data.push(data.results[i]);
          }

        });
      }

      //word search 搜索
      $scope.word_search = function()
      {
        name = $scope.name;
        $location.path("word_search_inter/" + name);
      }
    })


//app_rank的控制器
    .controller('app_rank_controller', function($scope, $http, $location,app)
    {
      document.title = "APP排行榜_AppBK.com";

      $scope.rank_type_name = "免费榜单";
      $scope.rank_type = 'topfreeapplications';
      var limit = 30;
      //获得一级类别信息
      $scope.categories = app.get_categories().query();

      //获得游戏二级类别信息
      $scope.game_categories = app.get_game_categories().query();


      //获得每个类型的app top 排行榜，只要30个，不翻页
      $scope.category_selected = "总榜";
      get_app_rank( $scope.category_selected,$scope.rank_type,1);

      //获得某个类别下的app排行
      $scope.get_category_app_rank = function(category)
      {
        get_app_rank(category ,$scope.rank_type , 1);
      }
      $scope.update_app_rank_type = function(rank_type){
        if (rank_type == $scope.rank_type){

          return;
        }else {

          $scope.rank_type = rank_type;
          if (rank_type == 'topfreeapplications') {
            $scope.rank_type_name = "免费榜单";
          }else if (rank_type == 'toppaidapplications'){
            $scope.rank_type_name = "付费榜单";
          }else if (rank_type == 'topgrossingapplications'){
            $scope.rank_type_name = "畅销榜单";
          }

          get_app_rank($scope.category_selected ,$scope.rank_type , 1);


        }

      }


      //翻页事件
      $scope.page_changed = function()
      {
        //console.log('Page changed to: ' + $scope.current_page);
        category = $scope.category_selected;
        get_app_rank(category,$scope.rank_type,$scope.current_page);
      }
      //获得app 排行信息
      //page，页码
      function get_app_rank(category,rank_type,page)
      {
        var start = 30 * (page - 1);
        $scope.start = start;

        $scope.category_selected = category;
        $scope.app_rank_show_wait = true;
        //rank_type = ["topfreeapplications","toppaidapplications","topgrossingapplications"];//榜单类型
        //获得每个榜单的内容
        $scope.app_rank = {};

        //考虑到异步，需要分开来写
        //console.log('rank_type=' + rank_type );
        app.get_app_rank().get({"c":category, "rank_type":rank_type, "start":start, "limit":limit},function(data)
        {
          $scope.app_rank = data.results;
          $scope.app_rank_show_wait = false;

          if (page==1) //如果是首次调用，进行初始化操作
          {
            //翻页构造，一般用在页面的第一页初始化部分
            $scope.total_items = data.num; //总数据数
            $scope.items_per_page = limit; //每页的记录数
            $scope.start = 0;//html的记录index显示
            $scope.current_page = 1;//设置当前页
          }
        });

        //app.get_app_rank().get({"c":category, "rank_type":rank_type[1], "start":start, "limit":limit},function(data)
        //{
        //  $scope.app_rank[ rank_type[1] ] = data.results;
        //  $scope.app_rank_show_wait = false;
        //});
        //
        //app.get_app_rank().get({"c":category, "rank_type":rank_type[2], "start":start, "limit":limit},function(data)
        //{
        //  $scope.app_rank[ rank_type[2] ] = data.results;
        //  $scope.app_rank_show_wait = false;
        //});

      }

      //app search 搜索
      $scope.app_search = function()
      {
        var name = $scope.name;
        $location.path("app_search/" + name);
      }
    })

//app search控制器
    .controller('app_search_controller', function($scope, $localStorage,$routeParams,user_app, app, word)
    {

      //接收参数，获得搜索结果
      var name = $routeParams.name;
      get_all_app_search_results(name,1);
      $scope.name = name;
      document.title =name+"_搜索结果_AppBK.com";

      //获得关键词热度
      word.get_word_hot_rank().get({"n":name},function(data)
      {
        $scope.word_rank = data.rank;
      });

      //获得搜索词suggestion
      word.get_word_suggetion().query({"n":name},function(data)
      {
        $scope.word_suggestion = data;
      });


      var limit = 30;//每一页结果个数

      //翻页事件
      $scope.page_changed = function()
      {
        var name = $scope.name;
        get_all_app_search_results(name,$scope.current_page);
      }

      //获得关键词的全部搜索结果,和苹果搜索结果一致的搜索结果
      function get_all_app_search_results(name,page)
      {
        $scope.app_search_show_wait = true;
        $scope.word_search_results  = {};

        var start = 30 * (page - 1);
        $scope.start = start;

        //获得搜索结果，全部的搜索结果

        app.get_all_app_search_results().get({"n":name,"start": start, "limit": limit}, function(data)
        {
          $scope.app_search_results = data.results;
          $scope.update_time = data.update_time;

          //如果name输入的是app_id,并且有搜索结果，则直接跳转到app内容页
          var pattern_app_id = /^\d{6,13}$/;//app id的pattern,6到13位数字

          if ( pattern_app_id.test(name) && data.results.length != 0 )
          {
            window.location = 'user_main.html#/app_content/' + data.results[0].app_id;
          }

          if (start == 0) { //如果是首次调用
            //翻页构造
            $scope.total_items = data.num; //总数据数
            $scope.items_per_page = limit; //每页的记录数
            $scope.current_page = 1;//设置当前页
          }

          $scope.app_search_show_wait = false;
        });

      }


      //根据app_id添加app
      $scope.add_user_app = function(app_id)
      {
        console.log("app_search:add_user_app" + app_id );
        if(typeof($localStorage.email) == "undefined") //如果没有登录
        {
          window.location = 'index.html#/index_login';

          return;
        }


        //真实后台添加数据
        user_app.add_user_app().get({"email":$localStorage.email,"token":$localStorage.token,"app_id":app_id},function(data)
        {
          ////刷新页面
          //get_user_apps();
          //window.location = 'user_main.html';

        });
      }
    })

//word search控制器
    .controller('word_search_controller', function($scope, $routeParams, word)
    {

      //接收参数，获得搜索结果
      var name = $routeParams.name;
      $scope.name = name;
      get_word_search_results(name);

      document.title = name+"_关键词搜索_AppBK.com";


      //点击，获得搜索app结果
      $scope.search_word = function()
      {
        var name = $scope.name;
        get_word_search_results(name);
      }



      //获得关键词的title搜索结果
      function get_word_search_results(name)
      {
        $scope.app_search_show_wait = true;
        $scope.word_search_results  = {};
        word.get_word_search_results().query({"n":name},function(data)
        {
          $scope.word_search_results = data;
          if ( data.length == 0 ) //如果没有搜索结果
          {
            $scope.message = "没有相关结果";
          }
          $scope.app_search_show_wait = false;
        });
      }
    })


//word search international控制器
    .controller('word_search_inter_controller', function($scope, $routeParams, word)
    {

      //接收参数，获得搜索结果
      var name = $routeParams.name;
      $scope.name = name;
      $scope.countrys = [{name:"中国",code:"cn"},{name:"美国",code:"us"},{name:"泰国",code:"th"},{name:"日本",code:"jp"},{name:"韩国",code:"kr"},{name:"台湾",code:"tw"}];

      $scope.country_selected = $scope.countrys[0];


      get_word_search_results(name,$scope.country_selected);

      document.title = name+"_关键词搜索_AppBK.com";



      //点击，获得搜索app结果
      $scope.search_word = function()
      {
        var name = $scope.name;
        var country = $scope.country_selected;
        get_word_search_results(name,country);
      }


      $scope.select_country = function(country)
      {
        $scope.country_selected = country;
        console.log("select_country"+country);
        console.log("countrys:"+$scope.countrys);
        get_word_search_results($scope.name,country);

      }

      //获得关键词的title搜索结果
      function get_word_search_results(name,country)
      {
        $scope.app_search_show_wait = true;
        $scope.word_search_results  = {};
        word.get_word_inter_search_results().query({"n":name,"cc":country.code},function(data)
        {
          $scope.word_search_results = data;
          if ( data.length == 0 ) //如果没有搜索结果
          {
            $scope.message = "没有相关结果";
          }
          $scope.app_search_show_wait = false;
        });
      }
    })


//关键词趋势控制器
    .controller('word_rank_trend_controller', function($scope, $sce, $filter, $routeParams, app, word)
    {


      document.title = "热度查询_AppBK.com";
      //接收参数，获得关键词
      var name = $routeParams.name;
      $scope.n = name;

      get_word_rank_trend(name,30,"","");



      //选择时间段
      //周期数据
      $scope.period = {};
      var period_list = [{"show_name":"最近1个月","name":"最近1个月","value":30},
        {"show_name":"最近3个月","name":"最近3个月","value":90},
        {"show_name":"最近半年","name":"最近半年","value":180},
        {"show_name":"自定义","name":$sce.trustAsHtml("<div data-toggle=modal data-target=#myModal>自定义</div>"),"value":-1},
      ];
      $scope.period_list = period_list;
      $scope.period.selected = period_list[0]; //默认的显示选项

      $scope.select_peroid = function(limit) {
        if (-1!=limit)
        {
          get_word_rank_trend(name,limit,"","");
        }
      }


      //自定义日期选择确定
      $scope.select_date = function(start,end)
      {


        var start_date = $filter('date')(start,'yyyy-MM-dd');
        var end_date = $filter('date')(end,'yyyy-MM-dd');
        if (start_date && end_date) //如果都填写了才有效
        {
          get_word_rank_trend(name,"", start_date, end_date);
        }
        else //如果输入有问题，直接使用默认的30天内结果
        {
          get_word_rank_trend(name,30,"","");
        }
      }



      $scope.search = function (name)
      {
        get_word_rank_trend(name,30,"","");
      }

      function get_word_rank_trend(name,limit,start,end) {
        word.get_word_rank_trend().get({"n": name,"limit":limit,"start":start,"end":end}, function (data) {
          $('#trend').highcharts(data);
          $('#trend').append('<div class="highcharts-logo"></div>');
        })
      }
      /*
      document.title = "热度查询_AppBK.com";
      //接收参数，获得关键词
      var name = $routeParams.name;
      $scope.n = name;
      get_word_rank_trend(name);

      $scope.search = function (name)
      {
        get_word_rank_trend(name);
      }

      function get_word_rank_trend(name) {
        word.get_word_rank_trend().get({"n": name}, function (data) {
          $('#trend').highcharts(data);
          $('#trend').append('<div class="highcharts-logo"></div>');
        })
      }
      */
    })

