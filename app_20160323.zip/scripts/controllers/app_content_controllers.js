/**
 * Created by maris on 2015/10/21.
 * app内容控制器
 */


angular.module('rank')

  //关键词控制器
  //.controller('app_content_keyword_controller', function($scope,$localStorage ,$routeParams,app,user_app_keyword,uiGridConstants)
  //{
  //  //bootstrap tips
  //  $("[data-toggle='popover']").popover({trigger:'click| hover',placement:'top',html:true});
  //  //接收参数
  //  var app_id = $routeParams.app_id;
  //  document.title = "关键词_APPBK.com";
  //  //不需要重新请求的情况
  //  if($localStorage.app_content_app_id == $routeParams.app_id && $localStorage.app_content_app_info != null){
  //    $scope.app_info = $localStorage.app_content_app_info;
  //    document.title = $scope.app_info.name+"_关键词_APPBK.com";
  //  }else {
  //    $localStorage.app_content_app_id = $routeParams.app_id;
  //    app.get_app_info().get({"app_id":app_id},function(data){
  //      $scope.app_info = data;
  //      document.title = $scope.app_info.name+"_关键词_Appbk.com";
  //      $localStorage.app_content_app_info = data;
  //    });
  //  }
  //
  //
  //  //添加关注关键词
  //  $scope.add_user_watch_keyword = function(){
  //    console.log("add_user_watch_keywordn");
  //
  //    if(typeof($localStorage.email) == "undefined") //如果没有登录
  //    {
  //      window.location = "index.html#/index_login";
  //      console.log("window.location = #index_login");
  //    }else {
  //      console.log("else");
  //
  //      user_app_keyword.add_user_watch_keyword().get({"n":$scope.watch_keyword,"email":$localStorage.email,"app_id":app_id},function(data) {
  //        get_app_possible_keywords(1);
  //      });
  //    }
  //  }
  //
  //  var limit = 1000; //每页的记录个数
  //  get_app_possible_keywords(1);//第一页
  //  //加载更多数据
  //  $scope.load_more = function(current_page)
  //  {
  //    $scope.current_page = current_page + 1;
  //    get_app_possible_keywords(current_page+1);
  //    if ($scope.current_page >= $scope.max_page_num) {
  //      $scope.turn_page = false;
  //    }
  //    else {
  //      $scope.turn_page = true;
  //    }
  //  }
  //
  //
  //
  //  //获得app的搜索词覆盖
  //  function get_app_possible_keywords(page)
  //  {
  //    var start = limit * (page - 1);
  //    $scope.start = start;
  //
  //    user_app_keyword.get_app_word_two_date_compare().get({"app_id": app_id, "start": start, "limit": limit, "email": $localStorage.email, "token": $localStorage.token}, function (data) {
  //
  //     console.log("user_app_keyword.get_app_word_two_date_compare");
  //      $scope.app_content_keyword_wait = false;
  //      //插入新数据
  //      var top_num = data.top10_num; //top 10的关键词个数
  //      var top3_num = data.top3_num; //top 3的关键词个数
  //
  //      if(start == 0){
  //        //console.log("start == 0;" + $scope.word_grid.data.length);
  //        //$scope.word_grid.data.slice(0,$scope.word_grid.data.length);
  //        $scope.word_grid.data = [];
  //        //console.log("start == 0;" + $scope.word_grid.data.length);
  //      }
  //
  //
  //      for (var i=0;i<data.results.length;i++) {
  //        $scope.word_grid.data.push(data.results[i]);
  //      }
  //      $scope.top_num = top_num;
  //      $scope.top3_num = top3_num;
  //
  //      if (0 == data.results.length) {
  //        $scope.keywords_user = {};
  //        $scope.keywords_user.message = "暂无关键词";
  //      }
  //      if (start == 0) { //如果是首次调用
  //        //翻页构造
  //        $scope.total_items = data.num; //总数据数
  //        $scope.items_per_page = limit; //每页的记录数
  //        $scope.start = 0;//html的记录index显示
  //        $scope.current_page = 1;//设置当前页
  //        $scope.max_page_num = parseInt(data.num/limit) + 1;
  //        if ($scope.max_page_num >1) {
  //          $scope.turn_page = true;
  //        }
  //        else {
  //          $scope.turn_page = false;
  //        }
  //      }
  //
  //    });
  //  }
  //
  //  $scope.show_history_chart = function(compete_query){
  //    $('#myModal').modal('show');
  //    //HighChart 数据
  //    user_app_keyword.get_app_keyword_trend().get({"email":$localStorage.email,"token":$localStorage.token,"app_id":app_id,"n":compete_query}, function(data) {
  //      //展示到图标上
  //      $('#key_world_trend').highcharts(data);
  //    });
  //
  //  }
  //
  //  //使用ui gird
  //  //表格基础配置
  //  $scope.word_grid = {
  //    enableRowSelection: true,
  //    enableSelectAll: false,
  //    selectionRowHeaderWidth: 100,
  //    rowHeight: 35,
  //    enableRowHeaderSelection: true,
  //    showGridFooter:false,
  //    enableGridMenu: true,//menu
  //    exporterOlderExcelCompatibility: true,
  //    enableHorizontalScrollbar:"never",
  //    exporterCsvFilename: 'appbk.csv',
  //  };
  //
  //  console.log("hello");
  //
  //  var columm_config =  [
  //    {field: 'query', displayName: '关键词1',type:'string',width:150,cellTemplate:"<span style='align-content: center'  class='table_middle'><a target='_blank' href='#/app_search/{{MODEL_COL_FIELD}}' title='{{MODEL_COL_FIELD}}'>{{MODEL_COL_FIELD|limitTo:8}}</a></span>"},
  //    {field: 'rank', displayName: '搜索热度', type:'number', width:150,
  //      headerCellTemplate:"../views/headerCellTemplate/search_header_template.html",
  //      cellTemplate:"<h5><a href='index.html#/word_rank_trend/{{row.entity.query}}' target='_blank'><progressbar class='progress-striped table_middle' type='warning'  max='10000' value='MODEL_COL_FIELD'>{{MODEL_COL_FIELD}}</progressbar></a></h5>"},
  //    {field: 'increase', displayName: "同比排名",width:120, type:'number', headerCellTemplate:"../views/headerCellTemplate/increase_header_template.html"},
  //    {field: 'pos', displayName: "APP排名",width:120, type:'number'},
  //    {field: 'num', displayName: "搜索结果数",width:130, type:'number'},
  //    {field: 'query', displayName: '趋势',type:'string',width:100,cellTemplate:"<span  class='table_middle'><a style='align-content: center' title='趋势' class='btn' ng-click='grid.appScope.show_history_chart(MODEL_COL_FIELD)'>趋势</a></span>"},
  //
  //  ];
  //  $scope.word_grid.columnDefs = columm_config;
  //
  //
  //  //注册api
  //  //加载grid api 2，同时设置check选择函数
  //  $scope.word_grid.onRegisterApi = function(word_grid_api){
  //    //set gridApi on scope
  //    $scope.word_grid_api = word_grid_api;
  //    $scope.word_grid_api.grid.registerRowsProcessor( $scope.singleFilter, 200 );
  //
  //  }
  //
  //  $scope.filter_sign = 0;
  //  $scope.filter_button = "只显示核心词";
  //
  //  $scope.filter_table = function()
  //  {
  //    if ($scope.filter_sign == 0) {
  //      $scope.filter_sign = 1;
  //      $scope.filter_button = "显示全部词";
  //    }
  //    else
  //    {
  //      $scope.filter_sign = 0;
  //      $scope.filter_button = "只显示核心词";
  //    }
  //    $scope.word_grid_api.grid.refresh();
  //    //$scope.word_grid_api.grid.scrollTop();
  //    //$scope.word_grid_api.grid.prevScrollTop();
  //  }
  //
  //  $scope.singleFilter = function( renderableRows )
  //  {
  //    renderableRows.forEach( function( row )
  //    {
  //      if ( $scope.filter_sign == 1 ) //如果需要过滤
  //      {
  //        if ( row.entity["rank"]<4000 || row.entity["pos"]>100 ) {
  //          row.visible = false;
  //        }
  //      }
  //      else //如果不需要过滤
  //      {
  //        row.visible = true;
  //      }
  //    });
  //    return renderableRows;
  //  }
  //
  //})

  .controller('grid_header_with_tip_controller', function($scope,$routeParams){
    $scope.title = $routeParams.title;
    $scope.tips = $routeParams.tips;

  })
  .controller('grid_header_with_tip_controller',function($scope){
  })


  //排名趋势控制器
  .controller('app_content_trend_controller', function($scope,$routeParams,$localStorage, app,user_app_keyword)
  {

    //接收参数
    var app_id = $localStorage.app_id;
    document.title = "排名趋势_Appbk.com";
        app.get_app_info().get({"app_id":app_id},function(data){
        $scope.app_info = data;
        document.title = $scope.app_info.name+"_排名趋势_Appbk.com";
      });

    //周期数据
    $scope.period = {};
    var period_list = [{"name":"最近24小时","value":-1},{"name":"最近一周","value":7},{"name":"最近一月","value":30},{"name":"最近三个月","value":90}];
    $scope.period_list = period_list;
    $scope.period.selected = period_list[1]; //默认的显示选项

    $scope.select_peroid = function(limit) {
      get_app_rank_trend(limit);
    }

    //默认获得最近7天的数据
    get_app_rank_trend(7);

    //获得app的排名趋势变化数据
    //limit，最近多少天
    function get_app_rank_trend(limit) {
      if (limit!=-1) //按照天
      {
        app.get_app_rank_trend().get({"app_id": app_id, "limit": limit}, function (data) {
          $('#trend').highcharts(data);
          $('#trend').append('<div class="highcharts-logo"></div>');
        });
      }
      else //按照小时
      {
        app.get_app_rank_hourly_trend().get({"app_id": app_id}, function (data) {
          $('#trend').highcharts(data);
          $('#trend').append('<div class="highcharts-logo"></div>');
        });
      }
    }
  })

  //app评论控制器
  .controller('app_content_comment_controller', function($scope, $localStorage,$routeParams,app,app_comment,uiGridConstants)
  {
    //接收参数
    var app_id = $localStorage.app_id;
    document.title = "APP评论_Appbk.com";
    app.get_app_info().get({"app_id":app_id},function(data){
      $scope.app_info = data;
      document.title = $scope.app_info.name+"_APP评论_Appbk.com";
      //$localStorage.app_content_app_info = data;
    });

    //评论趋势图
    get_app_comment_trend(30);

    //所有评论
    var limit = 100; //每页的记录个数
    get_app_possible_keywords(1);//第一页


    //加载更多数据
    $scope.load_more = function(current_page)
    {
      $scope.current_page = current_page + 1;
      get_app_possible_keywords(current_page+1);
      if ($scope.current_page >= $scope.max_page_num)
      {
        $scope.turn_page = false;
      }
      else
      {
        $scope.turn_page = true;
      }
    }

    //获得app的搜索词覆盖
    function get_app_possible_keywords(page)
    {
      var start = limit * (page - 1);
      $scope.start = start;


      app_comment.get_app_comments().get({"app_id": app_id, "start": start, "limit": limit}, function (data) {
        //插入新数据
        for (var i=0;i<data.results.length;i++) {
          $scope.word_grid.data.push(data.results[i]);
        }

        if (0 == data.results.length) {
          $scope.keywords_user = {};
          $scope.keywords_user.message = "暂无关键词";
        }
        if (start == 0) { //如果是首次调用
          //翻页构造
          $scope.total_items = data.num; //总数据数
          $scope.items_per_page = limit; //每页的记录数
          $scope.start = 0;//html的记录index显示
          $scope.current_page = 1;//设置当前页
          $scope.max_page_num = parseInt(data.num/limit) + 1;
          if ($scope.max_page_num >1)
          {
            $scope.turn_page = true;
          }
          else
          {
            $scope.turn_page = false;
          }
        }

      });
    }

    //使用ui gird
    //表格基础配置
    $scope.word_grid = {
      enableFiltering: true,
      selectionRowHeaderWidth: 100,
      rowHeight: 35,
      enableRowHeaderSelection: true,
      showGridFooter:false,
      enableGridMenu: true,//menu
      exporterOlderExcelCompatibility: true,
      exporterCsvFilename: 'appbk.csv',
    };

    var columm_config =  [
      {field: 'name', displayName: '用户名',type:'number',width:150,enableFiltering: false},
      {field: 'title', displayName: '评论标题',type:'string',width:150,enableFiltering: false},
      {field: 'body', displayName: '评论内容', type:'string', width:300,enableFiltering: false},
      {field: 'rating', displayName: "星级",width:80, type:'number'
        ,filter:{
        type: uiGridConstants.filter.SELECT,
        selectOptions: [ { value: '5', label: '5星'}, {value: '4', label: '4星' }, { value: '3', label: '3星'}, { value: '2', label: '2星' }, { value: '1', label: '1星' } ]
      }
        ,headerCellClass: $scope.highlightFilteredHeader},
      {field: 'body.length', displayName: "内容长度",width:120, type:'number',enableFiltering: false},
      {field: 'date', displayName: "发布时间",width:200, type:'string',enableFiltering: false}
    ];
    $scope.word_grid.columnDefs = columm_config;

    $scope.header_title = "name";

    //注册api
    //加载grid api 2，同时设置check选择函数
    $scope.word_grid.onRegisterApi = function(word_grid_api){
      //set gridApi on scope
      $scope.word_grid_api = word_grid_api;

    }

    //获得app的评论趋势变化数据
    //limit，最近多少天
    function get_app_comment_trend(limit) {
      app_comment.get_app_comment_trend().get({"app_id": app_id, "limit": limit}, function (data) {
        $('#trend').highcharts(data);
        $('#trend').append('<div class="highcharts-logo"></div>');

      });
    }


  })


  //app的关键词对比服务
  //关键词控制器
  .controller('app_content_keyword_compare_controller', function($scope,$localStorage,$routeParams,app,user_app_keyword,word,uiGridConstants) {

    var compete_app_id = $routeParams.compete_app_id;

    //接收参数
    var app_id = $routeParams.app_id;
    document.title = "关键词对比_AppBK.com";

      app.get_app_info().get({"app_id":app_id},function(data){
        $scope.app_info = data;
        document.title = $scope.app_info.name+"_关键词对比_AppBK.com";
        $localStorage.app_content_app_info = data;
      });

      $scope.compete_app_info = app.get_app_info().get({"app_id": compete_app_id});

    $scope.word_grid = {
      enableRowSelection: true,
      enableSelectAll: false,
      selectionRowHeaderWidth: 100,
      rowHeight: 35,
      enableRowHeaderSelection: true,
      showGridFooter:false,
      enableGridMenu: true,//menu
      exporterOlderExcelCompatibility: true,
      enableHorizontalScrollbar:"never",
      exporterCsvFilename: 'appbk.csv',
    };

    var columm_config =  [
      {field: 'num', displayName: '序号',type:'number',width:'10%', cellTemplate: '<div class="ui-grid-cell-contents table-middle-style">{{grid.renderContainers.body.visibleRowCache.indexOf(row)+1}}</div>'},
      {field: 'query', displayName: '关键词',type:'string',width:'20%',cellTemplate:"<div class='ui-grid-cell-contents '><a target='_blank' href='#/app_search/{{MODEL_COL_FIELD}}' title='{{MODEL_COL_FIELD}}'>{{MODEL_COL_FIELD|limitTo:8}}</a></div>"},
      {field: 'rank', displayName: '搜索热度', type:'number', width:'20%',headerTooltip: "搜索热度：主要反映用户每天搜索该词的频率", cellTemplate:"<div class='ui-grid-cell-contents table-middle-style'><h5><progressbar class='progress-striped table_middle' type='warning'  max='10000' value='MODEL_COL_FIELD'>{{MODEL_COL_FIELD}}</progressbar></h5></div>"},
      {field: 'my_app_pos', displayName: "左边APP排名",width:'25%', type:'number'},
      {field: 'pos', displayName: "竞品APP排名",width:'25%', type:'number'},
    ];
    $scope.word_grid.columnDefs = columm_config;

    word.get_app_words_compare().query({"app_id": app_id, "compete_app_id": compete_app_id}, function (data) {
      //插入新数据
      $scope.word_grid.data = data;

    });

  })

