#!/bin/bash
#########################################################################
# Author: billczhang
# Created Time: Wed 08 Apr 2015 11:13:55 AM CST
# File Name: push.sh
# Description: 
#########################################################################
#step 1, add file
git add *
#step 2, commit
git commit -m "message "
#step 3, push
git push origin master

