#!/bin/sh
#更新本地副本到最新版本
cd /var/www/html/appbk_web
#step 3，update 确认
git pull git@git.oschina.net:appbk/appbk_web.git
