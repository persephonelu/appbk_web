'use strict';

/**
 * @ngdoc overview
 * @name appbkApp
 * @description
 * # appbkApp
 *
 * Main module of the application.
 */
//全局变量


angular
  .module('rank', [
    'ngCookies',
    'ngResource',
    'ngRoute',
    'ngStorage',
    'ui.bootstrap',
    'appbk_services',
    'appbk_directives',
    'ui.grid',
    'ui.grid.edit',
    'ui.grid.selection',
    'ui.grid.autoResize',
    'ui.grid.exporter',
    'ui.select',
    'ngSanitize', //html改写模板，这个不能少,ui.select
    'mgcrea.ngStrap',//date select
  ])
  .config(function ($routeProvider) {
    $routeProvider
      .when('/', {
        templateUrl: 'views/index_main.html',
        controller: 'index_main_controller'
      })
      .when('/index_login', {
        templateUrl: 'views/index_login.html',
        controller: 'index_login_controller'
      })
      .when('/index_register', {
        templateUrl: 'views/index_register.html',
        controller: 'index_register_controller'
      })
      .when('/index_about', {
        templateUrl: 'views/index_about.html'
      })
      .when('/index_contact', {
        templateUrl: 'views/index_contact.html'
      })
      .when('/tag_rank', {
        templateUrl: 'views/tag_rank.html',
        controller: 'tag_rank_controller'
      })
      .when('/word_rank', {
        templateUrl: 'views/word_rank.html',
        controller: 'word_rank_controller'
      })
      .when('/app_rank', {
        templateUrl: 'views/app_rank.html',
        controller: 'app_rank_controller'
      })
      .when('/app_search/:name', {
        templateUrl: 'views/app_search.html',
        controller: 'app_search_controller'
      })
      .when('/word_search/:name', {
        templateUrl: 'views/word_search.html',
        controller: 'word_search_controller'
      })
      .when('/word_rank_trend/:name', {//关键词热度趋势
        templateUrl: 'views/word_rank_trend.html',
        controller: 'word_rank_trend_controller'
      })
      .when('/word_rank_trend', {//关键词热度趋势，无输入
        templateUrl: 'views/word_rank_trend.html',
        controller: 'word_rank_trend_controller'
      })
      //.when('/app_content/:app_id', {
      //  templateUrl: 'views/app_content_trend.html', //兼容，把原来的content导入到这里
      //  controller: 'app_content_trend_controller'
      //})
      //.when('/app_content_keyword/:app_id', {
      //  templateUrl: 'views/app_content_keyword.html',
      //  controller: 'app_content_keyword_controller'
      //})
      //.when('/app_content_compete/:app_id', { //app内容页，竞品控制器
      //  templateUrl: 'views/app_content_compete.html',
      //  controller: 'app_content_compete_controller'
      //})
      //.when('/app_content_trend/:app_id', { //app内容页，排名趋势
      //  templateUrl: 'views/app_content_trend.html',
      //  controller: 'app_content_trend_controller'
      //})

      //.when('/app_content_comment/:app_id', { //app评论
      //  templateUrl: 'views/app_content_comment.html',
      //  controller: 'app_content_comment_controller'
      //})
      .when('/app_content_keyword_compare/:app_id/:compete_app_id', { //app关键词对比
        templateUrl: 'views/app_content_keyword_compare.html',
        controller: 'app_content_keyword_compare_controller'
      })
      .when('/app_tools_aso', {
        templateUrl:'views/app_tools_aso.html',
        controller:'app_tools_aso_controller'
      })
      .when('/app_tools_search', {
        templateUrl:'views/app_tools_search.html',
        controller:'app_tools_search_controller'
      })
      .when('/app_tools_seg', {
        templateUrl:'views/app_tools_seg.html',
        controller:'app_tools_seg_controller'
      })
      .when('/app_tools_test', {
        templateUrl:'views/app_tools_test.html',
        controller:'app_tools_test_controller'
      })
      .when('/app_tools_combine', { //组词
        templateUrl:'views/app_tools_combine.html',
        controller:'app_tools_combine_controller'
      })
      .when('/app_tools_combine/:n', { //组词,带参数
        templateUrl:'views/app_tools_combine.html',
        controller:'app_tools_combine_controller'
      })
      .when('/grid_header_with_tip/:title/:tips', { //组词,带参数
        templateUrl:'views/grid_header_with_tip.html',
        controller:'grid_header_with_tip_controller'
      })

        .when('/user_apps', {
          templateUrl:'views/user_app_manage.html',
          controller:'user_app_manage_controller'
        })
      //国际化页面

      .when('/word_rank_inter', {
        templateUrl: 'views/word_rank_inter.html',
        controller: 'word_rank_inter_controller'
      })
      .when('/word_search_inter/:name', {
        templateUrl: 'views/word_search_inter.html',
        controller: 'word_search_inter_controller'
      })

      .otherwise({
        redirectTo: '/'
      });
  });



